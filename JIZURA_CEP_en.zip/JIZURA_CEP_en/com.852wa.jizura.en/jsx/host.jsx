/*  JIZURA \u5B57\u9762 \u2014 host script of the After Effects CEP panel (ExtendScript, ES3).
    The panel (index.html) talks to After Effects through evalScript('JZCEP.xxx(...)'); every call returns a JSON string.
    The build engine itself (jizura_core.jsx, the same code as JIZURA_AE.jsx without its ScriptUI) is loaded once by init().  */
var JZCEP = (function () {
    var ROOT = null, lastComp = null, lastPlan = null;
    try { ROOT = File($.fileName).parent.parent.fsName; } catch (e) {}

    // ---- tiny JSON writer (ExtendScript has no JSON object)
    function q(s) {
        s = String(s); var out = '"', i, c, ch, h;
        for (i = 0; i < s.length; i++) {
            ch = s.charAt(i); c = s.charCodeAt(i);
            if (ch === '"' || ch === '\\') out += '\\' + ch;
            else if (c < 32 || c > 126) { h = c.toString(16); out += '\\u' + ('0000' + h).slice(-4); }
            else out += ch;
        }
        return out + '"';
    }
    function str(v) {
        var t = typeof v, a, i, k;
        if (v === null || v === undefined) return 'null';
        if (t === 'number') return isFinite(v) ? String(v) : 'null';
        if (t === 'boolean') return v ? 'true' : 'false';
        if (t === 'string') return q(v);
        if (v instanceof Array) { a = []; for (i = 0; i < v.length; i++) a.push(str(v[i])); return '[' + a.join(',') + ']'; }
        a = []; for (k in v) if (v.hasOwnProperty(k)) a.push(q(k) + ':' + str(v[k]));
        return '{' + a.join(',') + '}';
    }
    function fail(msg) { return str({ ok: false, error: String(msg) }); }

    function core() {
        if (!$.global.JZ_CORE) {
            var f = File(ROOT + '/jsx/jizura_core.jsx');
            if (!f.exists) throw new Error('jizura_core.jsx not found: ' + f.fsName);
            $.evalFile(f);
        }
        return $.global.JZ_CORE;
    }
    // fonts: the same settings as the ScriptUI panel (JIZURA_AE.jsx \u2192 \uD3F0\uD2B8 tab), defaults otherwise
    function setting(k, d) { try { if (app.settings.haveSetting('JIZURA', k)) return decodeURIComponent(app.settings.getSetting('JIZURA', k)); } catch (e) {} return d; }
    function roles(C) {
        var d = C.roleDefault;
        return { display: setting('font_display', d.display), serif: setting('font_serif', d.serif), body: setting('font_body', d.body), mono: setting('font_mono', d.mono), __force: setting('forceFonts', '0') === '1' };
    }
    function findItem(id) {
        for (var i = 1; i <= app.project.numItems; i++) { var it = app.project.item(i); if (it.id === id) return it; }
        return null;
    }
    function activeComp() { var c = app.project.activeItem; return (c && c instanceof CompItem) ? c : null; }
    function audioLayerOf(c) {
        if (!c) return null;
        var sel = c.selectedLayers, i;
        for (i = 0; i < sel.length; i++) { try { if (sel[i].hasAudio && sel[i].source && sel[i].source.file) return sel[i]; } catch (e) {} }
        return null;
    }

    // ---- building runs as a job in short steps (the panel calls step() again and again), so After Effects gets
    //      control back between steps and never shows "not responding" on long songs
    var job = null, jobT0 = 0, jobPlan = null, jobAudio = false;
    function start(s, audioId, light) {
        var C, plan;
        job = null; jobT0 = new Date().getTime();
        try { C = core(); } catch (e0) { return fail('engine: ' + e0.toString()); }
        try { plan = C.parse(s); } catch (e1) { return fail('JSON: ' + e1.toString()); }
        if (!plan || !plan.cuts || !plan.style) return fail('JIZURA \uAD6C\uC131 \uB370\uC774\uD130\uAC00 \uC544\uB2D9\uB2C8\uB2E4');
        if (!C.start) return fail('engine: jizura_core.jsx is too old \u2014 reinstall the panel');
        var au = audioId ? findItem(audioId) : null, err = null, off = +plan.audioOffset || 0;
        app.beginUndoGroup('JIZURA');
        try { job = C.start(plan, { roles: roles(C), audioItem: au, audioStart: -off, light: !!light }); }
        catch (e2) { err = e2.toString() + (e2.line ? ' (line ' + e2.line + ')' : ''); job = null; }
        finally { app.endUndoGroup(); }
        if (!job) return fail(err || 'build');
        jobPlan = plan; jobAudio = !!au;
        return str({ ok: true, name: job.comp.name, total: job.total, events: job.events });
    }
    function result(C, cancelled) {
        var comp = job.comp, log = C.log() || [], notes = [];
        for (var i = 0; i < log.length && i < 20; i++) notes.push(String(log[i]));
        lastComp = comp; lastPlan = jobPlan;
        return { ok: true, done: true, cancelled: cancelled, name: comp.name, cuts: job.done, total: job.total, secs: (new Date().getTime() - jobT0) / 1000,
            fallbacks: C.fallbacks(), notes: notes, notesTotal: log.length, audio: jobAudio, missingFonts: C.missingFonts ? C.missingFonts() : [], fontCheck: !(C.fontCheckUnavailable && C.fontCheckUnavailable()) };
    }
    function step(ms) {
        if (!job) return fail('\uC0DD\uC131 \uC911\uC778 \uCEF4\uD3EC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4');
        var C = core(), err = null;
        app.beginUndoGroup('JIZURA');
        try { job.step(ms > 0 ? ms : 1200); }
        catch (e) { err = e.toString() + (e.line ? ' (line ' + e.line + ')' : ''); }
        finally { app.endUndoGroup(); }
        if (err) { job = null; return fail(err); }
        if (!job.finished) return str({ ok: true, done: false, phase: job.phase, cuts: job.done, total: job.total, eventsDone: job.eventsDone, events: job.events });
        var r = result(C, !!job.cancelled); job = null;
        return str(r);
    }
    function build(s, audioId) {           // all at once (older panels)
        var r = start(s, audioId); if (!job) return r;
        var out; do { out = step(1e9); } while (job);
        return out;
    }
    function readTemp(path) {
        var f = File(path);
        if (!f.exists) return null;
        f.encoding = 'UTF-8'; f.open('r'); var s = f.read(); f.close();
        try { f.remove(); } catch (e) {}
        return s;
    }

    return {
        // root = the extension folder (the panel passes it; $.fileName is only a fallback)
        init: function (root) {
            if (root) ROOT = root;
            try { var C = core(); return str({ ok: true, app: app.version, engine: C.version, styles: C.data.styleOrder.length }); }
            catch (e) { return fail(e.toString()); }
        },
        info: function () {
            var c = activeComp(), r = { ok: true, app: app.version, comp: null };
            if (c) {
                r.comp = { name: c.name, width: c.width, height: c.height, fps: c.frameRate, duration: c.duration, markers: c.markerProperty.numKeys };
                var L = c.selectedLayers.length ? c.selectedLayers[0] : null;
                if (L) r.layer = { name: L.name, markers: L.property('ADBE Marker').numKeys, start: L.startTime };
                var A = audioLayerOf(c); if (A) r.audio = { name: A.source.name, start: A.startTime };
            }
            return str(r);
        },
        // the audio file behind the selected layer of the active comp (the panel analyses it for beats)
        selectedAudio: function () {
            var c = activeComp();
            if (!c) return fail('\uCEF4\uD3EC\uB97C \uC5F4\uACE0 \uACE1 \uB808\uC774\uC5B4\uB97C \uC120\uD0DD\uD574 \uC8FC\uC138\uC694');
            var L = audioLayerOf(c);
            if (!L) return fail('\uACE1(\uC624\uB514\uC624 \uD30C\uC77C) \uB808\uC774\uC5B4\uB97C \uC120\uD0DD\uD574 \uC8FC\uC138\uC694');
            return str({ ok: true, id: L.source.id, name: L.source.name, path: L.source.file.fsName, start: L.startTime, comp: c.name });
        },
        // marker times \u2192 line start times (seconds from the start of the song)
        markers: function () {
            var c = activeComp();
            if (!c) return fail('\uCEF4\uD3EC\uB97C \uC5F4\uC5B4 \uC8FC\uC138\uC694');
            var L = c.selectedLayers.length ? c.selectedLayers[0] : null, mk = null, src = 'comp', i;
            try { if (L && L.property('ADBE Marker').numKeys > 0) { mk = L.property('ADBE Marker'); src = 'layer'; } } catch (e) {}
            if (!mk) mk = c.markerProperty;
            if (!mk || mk.numKeys < 1) return fail('\uB9C8\uCEE4\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4(\uACE1 \uB808\uC774\uC5B4\uB098 \uCEF4\uD3EC\uC5D0 \uB9C8\uCEE4\uB97C \uCC0D\uC5B4 \uC8FC\uC138\uC694)');
            var A = audioLayerOf(c), off = A ? A.startTime : 0, t = [];
            for (i = 1; i <= mk.numKeys; i++) t.push(Math.max(0, mk.keyTime(i) - off));
            return str({ ok: true, source: src, times: t, offset: off });
        },
        buildFromFile: function (path, audioId) { var s = readTemp(path); return s == null ? fail('\uAD6C\uC131 \uB370\uC774\uD130 \uC784\uC2DC \uD30C\uC77C\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4') : build(s, audioId); },
        buildFromString: function (enc, audioId) { return build(decodeURIComponent(enc), audioId); },
        startFromFile: function (path, audioId, light) { var s = readTemp(path); return s == null ? fail('\uAD6C\uC131 \uB370\uC774\uD130 \uC784\uC2DC \uD30C\uC77C\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4') : start(s, audioId, light); },
        startFromString: function (enc, audioId, light) { return start(decodeURIComponent(enc), audioId, light); },
        step: function (ms) { return step(ms); },
        cancel: function () { if (job) job.cancelled = true; return str({ ok: true }); },
        // check the last built comp in this AE session: evaluates every expression and saves JIZURA_report.txt
        diagnose: function () {
            var C; try { C = core(); } catch (e0) { return fail(e0.toString()); }
            var ok = false; try { ok = !!(lastComp && lastComp.name); } catch (e) { ok = false; }
            if (!ok) return fail('\uBA3C\uC800 \uC774 \uD328\uB110\uC5D0\uC11C \uCEF4\uD3EC\uB97C \uB9CC\uB4E4\uC5B4 \uC8FC\uC138\uC694');
            var r = C.diagnose(lastComp, lastPlan, 120), path = C.saveReport(r.text);
            return str({ ok: true, errors: r.errors, expressions: r.expressions, partial: r.partial, path: path });
        }
    };
})();
